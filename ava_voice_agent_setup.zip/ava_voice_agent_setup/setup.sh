#!/bin/bash
# AvA Voice Agent Setup Script for Ubuntu Server

echo "Updating and installing dependencies..."
sudo apt update && sudo apt upgrade -y
sudo apt install curl git build-essential python3 python3-pip -y

echo "Installing Ollama..."
curl -fsSL https://ollama.com/install.sh | sh

echo "Pulling Gemma 2B model..."
ollama pull gemma:2b

echo "Installing Python tools..."
pip3 install pymupdf

echo "Cloning Kokoro TTS..."
git clone https://github.com/NikolaJankovic/kokoro-tts.git
cd kokoro-tts
pip3 install -r requirements.txt
cd ..

echo "Setup complete. Run the model with: ollama run gemma:2b"
